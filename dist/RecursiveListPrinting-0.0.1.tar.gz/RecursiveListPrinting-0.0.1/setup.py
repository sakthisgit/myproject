from distutils.core import setup

setup(
        name = 'RecursiveListPrinting',
        version = '0.0.1',
        py_modules = ['pymodules/print_list'],
        author = 'Sakthi Saravanakumar P',
        author_email = 'sakthisaravanan.p@gmail.com',
        description = 'A simple printer for nested list',    
    )
